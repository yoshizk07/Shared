/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file qtcell.h
 \brief �i�q�̒P�ʖE��GUI�\���̃N���X
*/

#ifndef __QTCELL_H_INCLUDED
#define __QTCELL_H_INCLUDED

#include "qtwidgets.h"

class DTModel;

class QTCell : public MyQTab
{
  Q_OBJECT

private:
  DTModel& model;

  enum { ID_SHAPE, ID_UNIT, ID_VECTOR, ID_ALIGNMENT };

public:
  QTCell( DTModel& _model, const int id );
public slots:
  void update( void );
private slots:
  void edit( const MyEvent& ev );
};

#endif // __QTCELL_H_INCLUDED
