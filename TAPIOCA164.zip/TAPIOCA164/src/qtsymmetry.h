/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file qtsymmetry.h
 \brief �i�q�̑Ώ̐���GUI�\���̃N���X
*/

#ifndef __QTSYMMETRY_H_INCLUDED
#define __QTSYMMETRY_H_INCLUDED

#include "qtwidgets.h"

class DTModel;

class QTSymmetry : public MyQTab
{
  Q_OBJECT

private:
  DTModel& model;

  enum { ID_SYMMETRY };

  QPlainTextEdit* plain_symmetry;
  QLabel* lavel_has_inversion;

public:
  QTSymmetry( DTModel& _model, const int id );
public slots:
  void update( void );
private slots:
  void edit( const MyEvent& ev );
};

#endif // __QTSYMMETRY_H_INCLUDED
