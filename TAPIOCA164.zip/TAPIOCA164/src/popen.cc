/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#include <stdio.h>
#include <unistd.h>

main()
{
  FILE* fptr = popen("./hello","r");

  char buf[1024];

  while( fgets(buf,sizeof(buf),fptr)){
    printf("[%s]\n", buf);
  }
  pclose(fptr);
}
