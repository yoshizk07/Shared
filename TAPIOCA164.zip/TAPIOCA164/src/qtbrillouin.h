/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file qtbrillouin.h
 \brief �u�����A���]�[����GUI�\���̃N���X
*/

#ifndef __QTBRILLOUIN_H_INCLUDED
#define __QTBRILLOUIN_H_INCLUDED

#include "qtwidgets.h"

class DTModel;

class QTBrillouin : public MyQTab
{
  Q_OBJECT

private:
  DTModel& model;
  QTableWidget* table;

  enum { ID_CLEAR, ID_DEFAULT };

public:
  QTBrillouin( DTModel& _model, const int id );

public slots:
  void update( void );
private slots:
  void edit( const MyEvent& ev );
  void itemSelected( void );
  void itemEdited( QTableWidgetItem* );
};

#endif // __QTBRILLOUIN_H_INCLUDED

