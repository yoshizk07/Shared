/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file qtalignment.cc
 \brief �i�q�̌��q�z�u��GUI�\���̃N���X
*/

#include "qtalignment.h"

QTAlignment::QTAlignment( DTModel& _model, const int id ) : MyQTab(id), model(_model)
{
}

void QTAlignment::edit( const MyEvent& ev )
{
}

void QTAlignment::update( void )
{
}
