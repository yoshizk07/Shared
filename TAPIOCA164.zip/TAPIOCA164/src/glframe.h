/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file glframe.h
 \brief �O�����t�B�[���h�̗̈�g��GL�\���̃N���X
*/

#ifndef __GLFRAME_H_INCLUDED
#define __GLFRAME_H_INCLUDED

#include "glbase.h"

class DTModel;

class GLFrame : public GLBase
{
private:
  DTModel& model;

public:
  GLFrame( DTModel& _model ) : model(_model) {}

public:
  void update( void );
};

#endif // __GLFRAME_H_INCLUDED
