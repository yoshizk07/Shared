/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

/*!
 \file qtalignment.h
 \brief �i�q�̌��q�z�u��GUI�\���̃N���X
*/

#ifndef __QTALIGNMENT_H_INCLUDED
#define __QTALIGNMENT_H_INCLUDED

#include "qtwidgets.h"

class DTModel;

class QTAlignment : public MyQTab
{
  Q_OBJECT

private:
  DTModel& model;

  enum { ID_ALIGNMENT };

public:
  QTAlignment( DTModel& _model, const int id );
public slots:
  void update( void );
private slots:
  void edit( const MyEvent& ev );
};

#endif // __QTALIGNMENT_H_INCLUDED
