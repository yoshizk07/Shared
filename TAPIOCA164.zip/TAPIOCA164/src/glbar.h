/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#ifndef __GLBAR_H_INCLUDED
#define __GLBAR_H_INCLUDED

#include "glbase.h"

class DTModel;
class QGLWidget;

class GLBar : public GLBase
{
private:
  DTModel& model;
  QGLWidget* qglwidget;

public:
  GLBar( DTModel& _model, QGLWidget* _qglwidget ) :
    model(_model), qglwidget(_qglwidget) {}

public:
  void draw( void );
  void update( void );
};

#endif // __GLBAR_H_INCLUDED
