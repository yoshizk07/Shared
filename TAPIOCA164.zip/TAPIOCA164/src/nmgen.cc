/*
 Copyright (c) 2014 Shinji Tsuneyuki
 This file is distributed under the terms of the GNU General Public License version 3.
 */

#include <stdio.h>
#include <string.h>

main()
{
  char buf[1024];
  char type[16], name[128];
  const char* format;
  char amp;

  while(fgets(buf,sizeof(buf),stdin)){
    if( 2 != sscanf(buf,"%s %[^;\[]", type, name ) ){
      printf("//-------\n");
      continue;
    }
    if( strchr(buf,'[') ){
      amp = ' ';
    }
    else{
      amp = '&';
    }

    {
      if( !strcmp(type,"int") ){
	format="\%d";
      }
      else if( !strcmp(type,"double") ){
	format="\%lf";
      }
      else if( !strcmp(type,"char") ){
	format="\%s";
      }
      printf(
	     "else if( !strcmp(name,\"%s\") ){\n"
	     "\tif( 1 != sscanf(value,\"%s\", %ctappinput.%s ) ){\n"
	     "\t\tprintf(\"broken %s.\\n\");\n"
	     "\t}\n"
	     "}\n", name, format, amp, name, name );
    }
  }
}


